<?php 

return [
    
    'not_found' => 'لم يتم العثور على الإعلان',
];
