<?php

return [
    'vehicles' => 'مركبات',
    'real_estate' => 'عقارات',
    'electronics' => 'إلكترونيات',
];
