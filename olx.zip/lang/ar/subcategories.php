<?php

return [
    'cars' => 'سيارات',
    'motorcycle' => 'دراجات نارية',
    'mobiles' => 'موبايلات',
    'laptops' => 'لابتوبات',
    'computers' => 'كمبيوترات',
    'tv' => 'تليفزيونات',
    'commercial_property' => 'عقارات تجارية',
    'residential_property' => 'عقارات سكنية',
    'lands' => 'أراضي',
];
