<?php

return [
    'created_success' => 'تم إنشاء الإعلان بنجاح',
    'updated_success' => 'تم تحديث الإعلان بنجاح',
    'deleted_success' => 'تم حذف الإعلان بنجاح',
    'system_updating' => 'نقوم بتحديث النظام الآن، حاول مرة أخرى لاحقًا',
     'error_occurred' => 'حدث خطأ، حاول مرة أخرى لاحقًا',
     'advertising_not_found' => 'الإعلان غير موجود',
     'failure' => 'فشلت العملية، حاول مرة أخرى لاحقًا',
     'unauthorized' => 'غير مصرح',
     'forbidden' => 'ممنوع',
];