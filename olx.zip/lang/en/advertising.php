<?php

return [
   
    'not_found' => 'Advertising not found',
];
