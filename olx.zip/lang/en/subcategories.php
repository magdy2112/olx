<?php

return [
    'cars' => 'Cars',
    'motorcycle' => 'Motorcycles',
    'mobiles' => 'Mobiles',
    'laptops' => 'Laptops',
    'computers' => 'Computers',
    'tv' => 'TVs',
    'commercial_property' => 'Commercial Property',
    'residential_property' => 'Residential Property',
    'lands' => 'Lands',
];
