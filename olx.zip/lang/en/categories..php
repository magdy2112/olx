<?php

return [
    'vehicles' => 'Vehicles',
    'real_estate' => 'Real Estate',
    'electronics' => 'Electronics',
];