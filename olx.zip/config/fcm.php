<?php 

return [
    'firebase_project_id' => env('FIREBASE_PROJECT_ID'),
    'firebase_credentials' => env('FIREBASE_CREDENTIALS'),
];
