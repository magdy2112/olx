<?php 
return [
    'max_images_free' => 5,
    'max_images_pro' => 8,
];