<?php

namespace App\Swagger\Auth;

/**
 * @OA\PathItem(path="/api/auth")
 */

/**
 * @OA\Post(
 *     path="/api/auth/register",
 *     summary="Register a new user",
 *     description="Creates a new user account and sends an email verification link.",
 *     tags={"Auth"},
 *
 *     @OA\RequestBody(
 *         required=true,
 *         @OA\JsonContent(
 *             required={"name", "email", "password", "password_confirmation", "phone"},
 *             @OA\Property(property="name", type="string", example="Mohamed"),
 *             @OA\Property(property="email", type="string", format="email", example="test@example.com"),
 *             @OA\Property(property="password", type="string", example="password"),
 *             @OA\Property(property="password_confirmation", type="string", example="password"),
 *             @OA\Property(property="phone", type="string", example="01234567890"),
 *             @OA\Property(property="role", type="string", example="user"),
 *             @OA\Property(property="provider", type="string", nullable=true, example=null)
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=201,
 *         description="User registered successfully",
 *         @OA\JsonContent(
 *             @OA\Property(property="success", type="boolean", example=true),
 *             @OA\Property(property="message", type="string", example="user created successfully.")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=422,
 *         description="Validation Error"
 *     ),
 *
 *     @OA\Response(
 *         response=500,
 *         description="Internal server error"
 *     )
 * )
 */
class Register {}
