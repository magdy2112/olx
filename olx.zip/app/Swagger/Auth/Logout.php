<?php

namespace App\Swagger\Auth;

/**
 * @OA\PathItem(path="/api/auth")
 */

/**
 * @OA\Post(
 *     path="/api/auth/logout",
 *     summary="Logout user",
 *     description="Logs out the authenticated user and revokes the active token.",
 *     tags={"Auth"},
 *
 *     @OA\SecurityScheme(
 *         securityScheme="sanctum",
 *         type="apiKey",
 *         name="Authorization",
 *         in="header"
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Logout successful"
 *     ),
 *
 *     @OA\Response(
 *         response=401,
 *         description="User not authenticated or no active token"
 *     ),
 *
 *     @OA\Response(
 *         response=500,
 *         description="Internal server error"
 *     )
 * )
 */
class Logout {}
