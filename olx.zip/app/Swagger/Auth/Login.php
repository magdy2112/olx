<?php

namespace App\Swagger\Auth;
/**
 * @OA\PathItem(path="/api/auth")
 */

/**
 * @OA\Post(
 *     path="/api/auth/login",
 *     summary="User login",
 *     description="Logs the user in using email & password.",
 *     tags={"Auth"},
 *
 *     @OA\RequestBody(
 *         required=true,
 *         @OA\JsonContent(
 *             required={"email", "password"},
 *             @OA\Property(property="email", type="string", format="email", example="test@example.com"),
 *             @OA\Property(property="password", type="string", example="password")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Login success",
 *         @OA\JsonContent(
 *             @OA\Property(property="success", type="boolean", example=true),
 *             @OA\Property(property="message", type="string", example="success"),
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *                 @OA\Property(property="token", type="string", example="1|sdfg34t5g45t...")
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=401,
 *         description="Invalid credentials"
 *     ),
 *
 *     @OA\Response(
 *         response=403,
 *         description="Email not verified"
 *     ),
 *
 *     @OA\Response(
 *         response=500,
 *         description="Server error"
 *     )
 * )
 */
class Login {}
