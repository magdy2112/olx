<?php

namespace App\Swagger\Auth;
/**
 * @OA\PathItem(path="/api/auth")
 */

/**
 * @OA\Post(
 *     path="/api/auth/forgetpassword",
 *     summary="Send temporary password",
 *     description="Sends a temporary password to the user's email.",
 *     tags={"Auth"},
 *
 *     @OA\RequestBody(
 *         required=true,
 *         @OA\JsonContent(
 *             required={"email"},
 *             @OA\Property(property="email", type="string", example="user@example.com")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Temporary password sent to email"
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="User not found"
 *     ),
 *
 *     @OA\Response(
 *         response=500,
 *         description="Error sending email"
 *     )
 * )
 */
class ForgetPassword {}
