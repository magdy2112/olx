<?php

namespace App\Swagger\Auth;

/**
 * @OA\PathItem(path="/api/auth")
 */

/**
 * @OA\Post(
 *     path="/api/auth/resetPassword",
 *     summary="Reset user password",
 *     description="Resets the user password using a validated temporary password.",
 *     tags={"Auth"},
 *
 *     @OA\RequestBody(
 *         required=true,
 *         @OA\JsonContent(
 *             required={"email","tmp_password","password","password_confirmation"},
 *
 *             @OA\Property(property="email", type="string", example="test@example.com"),
 *             @OA\Property(property="tmp_password", type="string", example="TEMP1234"),
 *             @OA\Property(property="password", type="string", example="newpassword"),
 *             @OA\Property(property="password_confirmation", type="string", example="newpassword")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Password reset successfully"
 *     ),
 *
 *     @OA\Response(
 *         response=400,
 *         description="Invalid temporary password"
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="User not found"
 *     )
 * )
 */
class ResetPassword {}
