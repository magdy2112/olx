<?php

namespace App\Swagger\Auth;

/**
 * @OA\PathItem(path="/api/auth")
 */

/**
 * @OA\Post(
 *     path="/api/auth/email/resend-verification",
 *     summary="Resend verification email",
 *     description="Resends the email verification link to the user.",
 *     tags={"Auth"},
 *
 *     @OA\RequestBody(
 *         required=true,
 *         @OA\JsonContent(
 *             required={"email"},
 *             @OA\Property(property="email", type="string", example="test@example.com")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Verification email resent successfully"
 *     ),
 *
 *     @OA\Response(
 *         response=400,
 *         description="Email already verified"
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="User not found"
 *     )
 * )
 */
class ResendVerification {}
