<?php

namespace App\Swagger\Auth;
/**
 * @OA\PathItem(path="/api/auth")
 */

/**
 * @OA\Get(
 *     path="/api/auth/verify-email",
 *     summary="Verify email address",
 *     description="Verifies the user email using the signed URL sent via email.",
 *     tags={"Auth"},
 *
 *     @OA\Parameter(
 *         name="id",
 *         in="query",
 *         required=true,
 *         description="User ID",
 *         @OA\Schema(type="integer", example=1)
 *     ),
 *
 *     @OA\Parameter(
 *         name="hash",
 *         in="query",
 *         required=true,
 *         description="SHA1 hashed user email",
 *         @OA\Schema(type="string", example="9b74c9897bac770ffc029102a200c5de")
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Email verified successfully"
 *     ),
 *
 *     @OA\Response(
 *         response=400,
 *         description="Invalid or expired verification link"
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="User not found"
 *     )
 * )
 */
class VerifyEmail {}
