<?php

namespace App\Enum;



enum Apurpose: string
{
    case بيع = 'بيع';
    case شراء = 'شراء';

    case إيجار = 'إيجار';
}