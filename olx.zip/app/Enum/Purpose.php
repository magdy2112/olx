<?php

namespace App\Enum;

enum Purpose: string
{
    case Sell = 'sell';
    case Buy = 'buy';

    case Rent = 'rent';
}





