<?php

namespace App\Enum;

enum Role: string
{
    case User = 'user';
    case Admin = 'admin';

    case Prouser = 'prouser';
}