<?php

namespace App\Http\Data_object_transfer;
use App\Http\Requests\Auth\RegisterRequest;

class user_dto
{
     public $name;
     public $email;
     public $password;
     public $phone;
     public $role;
     public $provider;

     public function __construct($name, $email, $password, $phone, $role, $provider)
     {
         $this->name = $name;
         $this->email = $email;
         $this->password = $password;
         $this->phone = $phone;
         $this->role = $role;
         $this->provider = $provider;
     }

     public function Toarray(RegisterRequest $request)
     {
            $credentials = $request->validated();
         return [
             'name' => $credentials['name'],
             'email' => $credentials['email'],
             'password' => $credentials['password'],
             'phone' => $credentials['phone'],
             'role' => $credentials['role'],
             'provider' => $credentials['provider'],
         ];
     }
}

    
